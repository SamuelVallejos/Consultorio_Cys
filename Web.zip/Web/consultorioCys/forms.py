from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm


class CustomUserEditForm(forms.ModelForm):
    # Agrega campos adicionales si existen
    full_name = forms.CharField(max_length=100, required=False)  # Ejemplo de campo adicional
    phone = forms.CharField(max_length=15, required=False)       # Ejemplo de campo adicional

    class Meta:
        model = User
        fields = ['username', 'email']  # Asegúrate de que estos son los campos que quieres editar

    def save(self, commit=True):
        user = super().save(commit=False)
        # Guarda los campos adicionales en el modelo de usuario si es necesario
        user.username = self.cleaned_data['full_name']
        if commit:
            user.save()
        return user
    
class CustomUserCreationForm(forms.ModelForm):
    password1 = forms.CharField(label='Contraseña', widget=forms.PasswordInput)
    password2 = forms.CharField(label='Confirmar Contraseña', widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email']

    def clean_password2(self):
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Las contraseñas no coinciden.")
        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user
